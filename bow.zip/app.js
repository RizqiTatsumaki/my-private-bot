const cheerio = require("cheerio")
const fetch = require("node-fetch")

fetch(encodeURI(`https://api.kawalcorona.com/indonesia`))
.then(response => response.json())
.then(data => {
    res.json({
        status: true,
        creator: `${creator}`,
        result: {
            positif: `${data[0].positif}`,
            sembuh: `${data[0].sembuh}`,
            dirawat: `${data[0].dirawat}`,
            meninggal: `${data[0].meninggal}`,
        },
        message: "Tetap jalani protokol kesehatan dan Semangattt"
    })
})