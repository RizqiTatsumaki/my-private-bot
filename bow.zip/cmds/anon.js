const { MessageType } = require("@adiwajshing/baileys")
const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType

exports.run = (zef, msg, args, from, runnin) => {

}

exports.help = {
    name: "Anon",
    description: "enable / disabe anon mode",
    usage: "anon",
    cooldown: 5,
    kategori: "fun"
};