# Features
* Chatting with someone as anonymous (only text , other format update soon !)

# anonymous chat
bot whatsapp with node js and baileys

## &#x1F919; Connect With Me
[![Facebook](https://img.shields.io/badge/Facebook-%234267B2.svg?&style=for-the-badge&logo=facebook&logoColor=white)](https://facebook.com/zefian.zefian.98)
[![Telegram](https://img.shields.io/badge/Telegram-%230088cc.svg?&style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/Zefiann)
[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://instagram.com/zefianalfian)
[![WhatsApp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/6289630171792)

## &#x1F919; Special Thanks To

* <a href="https://github.com/ibnusyawall"><img alt="GitHub" src="https://img.shields.io/badge/ibnusyawall%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white"></a>
* <a href="https://github.com/Allviyan"><img alt="GitHub" src="https://img.shields.io/badge/Allviyan%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white"></a>
* <a href="https://github.com/onekill0503"><img alt="GitHub" src="https://img.shields.io/badge/richoarbianto%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white"></a>
* <a href="https://github.com/onekill0503/anonimchat-clone"><img alt="GitHub" src="https://img.shields.io/badge/onekill0503/anonimchat clone%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white"></a>
